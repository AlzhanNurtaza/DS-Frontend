export { LoginPage } from "./login";
export { RegisterPage } from "./register";
export { ForgotPasswordPage } from "./forgotPassword";
export { UpdatePasswordPage } from "./updatePassword";
